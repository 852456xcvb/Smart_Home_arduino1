BOUNCE 2
=====================

Debouncing library for Arduino or Wiring

by Thomas Ouellet Fredericks

with contributions from:

Eric Lowry, Jim Schimpf, Tom Harkaway and Joachim Krüger.


HAVE A QUESTION?
=====================
Please post your questions here :
http://forum.arduino.cc/index.php?topic=266132.0

DOWNLOAD
=====================

Download the latest version (version 2) here :

https://github.com/thomasfredericks/Bounce2/archive/master.zip


INSTALLATION
=====================
Put the "Bounce2" folder in your Arduino or Wiring "libraries" folder. 


DOCUMENTATION
=====================

The latest version (version 2) documentation can be found here : 

https://github.com/thomasfredericks/Bounce2/wiki


ABOUT BOUNCE 1 (ORIGINAL VERSION)
=====================

The original version of Bounce (Bounce 1) is included but not supported anymore.
