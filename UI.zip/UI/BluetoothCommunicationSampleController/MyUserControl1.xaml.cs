﻿namespace BluetoothCommunicationSampleController
{
    public partial class MyUserControl1
    {
        public MyUserControl1()
        {
            InitializeComponent();
        }
    }
}